// components/Main.jsx
import React from 'react';

const Main = () => {
    return (
        <>
            {/* Section: Hero */}
            <section className="hero" id="home">
                <img src="./images/header-shape.svg" id="header-shape" alt="Header Shape" />
                <div className="hero-content">
                    <h1>Empower Your Academic Journey</h1>
                    <p>
                        Introducing our innovative Learning Management System (LMS), designed to help students at all levels manage their
                        academic activities effectively. Track your classes, self-study hours, and extracurricular activities with ease.
                        Enjoy interactive calendars, real-time analytics, and personalized goal-setting features to enhance your academic
                        performance and cultivate disciplined study habits.
                    </p>
                    <div className="btn-container">
                        <button className="primary-btn btn">Login</button>
                        <button className="secondary-btn btn" id="explore-more-btn">
                            Explore More
                        </button>
                    </div>
                </div>
                <div className="hero-img">
                    <img src="./images/hero-image.svg" alt="Hero Image" />
                </div>
            </section>

            {/* Section: Features */}
            <section class="features" id="features">
                <h2>Why Choose Our LMS</h2>
                <p class="section-desc">
                    Our Learning Management System (LMS) is designed to provide a
                    comprehensive academic tracking solution, offering unique features to
                    enhance your learning journey. With real-time analytics, goal-setting
                    tools, and customizable options, our LMS is tailored to help you achieve
                    academic success and improve time management.
                </p>
                <div class="row">
                    <div class="column">
                        <i class="fas fa-calendar-alt"></i>
                        <h3>Comprehensive Tracking</h3>
                        <p>
                            Track all aspects of your academic life, including classes,
                            self-study hours, and extracurricular activities. Our LMS provides
                            detailed insights into your engagement with specific subjects and
                            activities.
                        </p>
                    </div>
                    <div class="column">
                        <i class="fas fa-chart-line"></i>
                        <h3>Interactive Analytics</h3>
                        <p>
                            Gain valuable insights into your learning progress with real-time
                            activity percentages, subject breakdowns, and monthly/yearly
                            visualizations through an interactive calendar.
                        </p>
                    </div>
                    <div class="column">
                        <i class="fas fa-cogs"></i>
                        <h3>Customizable Experience</h3>
                        <p>
                            Customize your LMS experience with theme options, including a dark
                            mode toggle, and data export functionalities. Set academic goals and
                            track your progress with tools designed to motivate and enhance your
                            productivity.
                        </p>
                    </div>
                </div>
            </section>

            {/* Section: Testimonial */}
            <section class="testimonial" id="testimonial">
                <h2>What Our Students Say</h2>
                <p class="section-desc">
                    Hear from students who have transformed their academic journeys with our
                    LMS. Discover how our platform has helped them achieve their goals and
                    improve their study habits.
                </p>
                <div class="row">
                    <div class="column">
                        <div class="testimonial-image">
                            <img src="./images/student-1.jpg" alt="Student 1" />
                        </div>
                        <p>
                            "Using this LMS has been a game-changer for my studies. The activity
                            tracking and real-time analytics have helped me stay organized and
                            focus on areas that need improvement. I've seen a significant boost
                            in my academic performance."
                        </p>
                        <h3>Emily Johnson</h3>
                    </div>
                    <div class="column">
                        <div class="testimonial-image">
                            <img src="./images/student-2.jpg" alt="Student 2" />
                        </div>
                        <p>
                            "This LMS has made managing my academic schedule so much easier. The
                            interactive calendar and goal-setting features keep me motivated and
                            on track. It's the perfect tool for any student looking to enhance
                            their productivity and time management skills."
                        </p>
                        <h3>Daniel Martinez</h3>
                    </div>
                </div>
            </section>

            {/* Section: Courses */}
            <section class="courses" id="courses">
                <h2>Track Your Academic Progress</h2>
                <p class="section-desc">
                    Our LMS offers a range of features to help you monitor and enhance your
                    academic journey. Explore key tools designed to support your learning,
                    track your activities, and achieve your goals.
                </p>
                <div class="row">
                    <div class="column">
                        <img src="./images/tracking.jpg" alt="Activity Tracking" />
                        <h3>Activity Tracking</h3>
                        <p>
                            Record and manage your class attendance, self-study hours, and
                            extracurricular activities. Our LMS provides a comprehensive view of
                            your academic and personal engagement.
                        </p>
                        <div class="courses-btn">
                            <button class="btn secondary-btn">Explore Features</button>
                        </div>
                    </div>
                    <div class="column">
                        <img src="./images/calender.jpg" alt="Interactive Calendar" />
                        <h3>Interactive Calendar</h3>
                        <p>
                            Visualize your activities and schedule with an interactive calendar.
                            Easily manage and plan your academic commitments and track your
                            progress throughout the year.
                        </p>
                        <div class="courses-btn">
                            <button class="btn secondary-btn">Learn More</button>
                        </div>
                    </div>
                    <div class="column">
                        <img src="./images/analytics.jpg" alt="Activity Analytics" />
                        <h3>Activity Analytics</h3>
                        <p>
                            Gain insights into your study habits with real-time analytics.
                            Monitor subject-wise performance and overall activity percentages to
                            identify areas for improvement and track your goals.
                        </p>
                        <div class="courses-btn">
                            <button class="btn secondary-btn">See Analytics</button>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Main;