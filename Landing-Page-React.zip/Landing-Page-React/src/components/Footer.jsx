// components/Footer.jsx
import React from 'react';

const Footer = () => {
    return (
        <footer className="footer__container">
            <div className="footer_section1">
                <div>
                    <h2 id="site-name" className="footer-text">
                        ProTrack
                    </h2>
                </div>

                <div className="section1__button_container">
                    <button>
                        <img src="./images/IndianFlag.jpg" alt="Indian Flag" style={{ width: '16px', height: '14px', paddingTop: '2px' }} />
                        <select style={{ border: 'none', backgroundColor: '#e8e8e8', cursor: 'pointer' }}>
                            <option>India</option>
                            <option>United States</option>
                            <option>Australia</option>
                            <option>New Zealand</option>
                            <option>Spain</option>
                            <option>England</option>
                        </select>
                    </button>
                    <button>
                        <i className="fa fa-globe"></i>
                        <select style={{ border: 'none', backgroundColor: '#e8e8e8', cursor: 'pointer' }}>
                            <option>English</option>
                            <option>Español</option>
                            <option>Français</option>
                            <option>Deutsch</option>
                            <option>Italiano</option>
                            <option>日本語</option>
                        </select>
                    </button>
                </div>
            </div>
            <div class="navigation_container">
                <div class="link_container">
                    <h5>About ProTrack</h5>
                    <div class="link_container_anchors">
                        <a href="#">Who We Are</a>
                        <a href="#">Blog</a>
                        <a href="#">Careers</a>
                        <a href="#">Press</a>
                        <a href="#">Contact Us</a>
                    </div>
                </div>

                <div class="link_container">
                    <h5>Features</h5>
                    <div class="link_container_anchors">
                        <a href="#">Activity Tracking</a>
                        <a href="#">Calendar Integration</a>
                        <a href="#">Analytics</a>
                        <a href="#">Customization</a>
                        <a href="#">Goal Setting</a>
                    </div>
                </div>

                <div class="link_container">
                    <h5>Student Portal</h5>
                    <div class="link_container_anchors">
                        <a href="#">Dashboard Overview</a>
                        <a href="#">Track Your Progress</a>
                        <a href="#">Join Study Groups</a>
                        <a href="#">Access Learning Materials</a>
                    </div>
                </div>

                <div class="link_container">
                    <h5>Learn More</h5>
                    <div class="link_container_anchors">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Security</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">Sitemap</a>
                    </div>
                </div>

                <div class="link_container">
                    <h5>Follow Us</h5>
                    <div class="social_media_icon_buttons">
                        <button><i class="fa-brands fa-linkedin-in"></i></button>
                        <button><i class="fa-brands fa-instagram"></i></button>
                        <button><i class="fa-brands fa-twitter"></i></button>
                        <button><i class="fa-brands fa-facebook"></i></button>
                        <button><i class="fa-brands fa-youtube"></i></button>
                        <div class="social_media_logos">
                            <img src="./images/app-store.png" alt="Apple Store" />
                            <img src="./images/google-play.png" alt="Play Store" id="img2" />
                        </div>
                    </div>
                </div>
            </div>
            <div className="disclaimer">
                By using ProTrack, you agree to our Terms of Service, Cookie Policy, Privacy Policy, and Content Policies. All trademarks
                are the property of their respective owners. © 2024 ProTrack™. All rights reserved.
            </div>
        </footer>
    );
};

export default Footer;