import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSticky, setIsSticky] = useState(false);

  // Handle scroll event
  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 0);
    };

    // Add scroll event listener
    window.addEventListener('scroll', handleScroll);

    // Clean up event listener
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLinkClick = (event, elementId) => {
    event.preventDefault();
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    // Close mobile menu after clicking a link
    setIsMenuOpen(false);
  };

  return (
    <header className={`${isSticky ? 'sticky' : ''}`}>
      <nav>
        <div className="header">
          <img src="./images/logo.png" id="logo" alt="logo" />
          <h2 id="site-name" className="fs-2 m-0">
            ProTrack
          </h2>
        </div>
        <i 
          className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`} 
          id="ham-menu" 
          onClick={toggleMenu}
          aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
        />

        <ul
          className={`lg:flex lg:items-center lg:space-x-8 ${
            isMenuOpen ? 'active' : ''
          } ${isSticky ? 'sticky-nav' : ''}`}
        >
          <li>
            <Link
              to="#features"
              className={`nav-link hover:text-gray-400 ${
                isSticky ? 'sticky-link' : ''
              }`}
              onClick={(event) => handleLinkClick(event, 'features')}
            >
              Features
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className={`nav-link hover:text-gray-400 ${
                isSticky ? 'sticky-link' : ''
              }`}
              onClick={(event) => handleLinkClick(event, 'download-app')}
            >
              Download App
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;