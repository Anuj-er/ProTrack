import React, { useState } from 'react';

const Card = ({ children, className }) => {
  return (
    <div 
      style={{
        backgroundColor: 'var(--card-background)',
        borderColor: 'var(--card-border)',
        color: 'var(--text-color)'
      }}
      className={`rounded-xl shadow-xl p-8 mx-auto max-w-2xl w-full border ${className}`}
    >
      {children}
    </div>
  );
};

const CardHeader = ({ children }) => {
  return <div className="mb-8 text-center">{children}</div>;
};

const CardTitle = ({ children }) => {
  return (
    <h2 
      style={{ color: 'var(--text-color)' }}
      className="text-3xl font-bold mb-2"
    >
      {children}
    </h2>
  );
};

const CardContent = ({ children }) => {
  return <div className="space-y-6">{children}</div>;
};

const AlertDialog = ({ open, onClose, children }) => {
  return open ? (
    <div className="fixed inset-0 z-50 overflow-y-auto backdrop-blur-sm"
         style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
      <div className="min-h-screen px-4 flex items-center justify-center">
        <div className="relative w-full max-w-4xl mx-auto">{children}</div>
      </div>
    </div>
  ) : null;
};

const AlertDialogAction = ({ children }) => {
  return <div className="mt-8 flex justify-end space-x-4">{children}</div>;
};

const ResponsiveContactForm = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const openModal = () => setIsOpen(true);
  const closeModal = () => setIsOpen(false);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark-mode');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--background-color)' }}>
      {/* Theme Toggle */}
      <button
        onClick={toggleTheme}
        className="fixed bottom-8 right-8 p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center"
        style={{ 
          backgroundColor: 'var(--base-shade-1)',
          color: 'var(--white-shade-1)',
          width: '60px',
          height: '60px',
          fontSize: '24px',
          border: '2px solid var(--white-shade-2)',
          zIndex: 40
        }}
        aria-label="Toggle theme"
      >
        {isDarkMode ? '☀️' : '🌙'}
      </button>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold sm:text-5xl md:text-6xl" style={{ color: 'var(--text-color)' }}>
            Let's Build Something
            <span style={{ color: 'var(--base-shade-1)' }}> Amazing Together</span>
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl" style={{ color: 'var(--black-shade-2)' }}>
            We're here to help bring your ideas to life. Our team of experts is ready to collaborate 
            with you on your next big project.
          </p>
        </div>

        {/* Features Grid */}
        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: '💡', title: 'Innovation First', desc: 'We bring creative solutions to every challenge' },
            { icon: '⚡', title: 'Fast Delivery', desc: 'Quick turnaround times without compromising quality' },
            { icon: '🤝', title: '24/7 Support', desc: 'Always here when you need us' }
          ].map((feature, idx) => (
            <div 
              key={idx}
              className="rounded-lg shadow-md p-6"
              style={{ 
                backgroundColor: 'var(--card-background)',
                borderColor: 'var(--card-border)',
                border: '1px solid'
              }}
            >
              <div className="text-2xl mb-4">{feature.icon}</div>
              <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--text-color)' }}>
                {feature.title}
              </h3>
              <p style={{ color: 'var(--black-shade-2)' }}>{feature.desc}</p>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <p className="text-xl mb-8" style={{ color: 'var(--black-shade-2)' }}>
            Ready to start your project? We'd love to hear from you!
          </p>
          <button
            type="button"
            onClick={openModal}
            style={{ backgroundColor: 'var(--base-shade-1)', color: 'var(--white-shade-1)' }}
            className="transition-colors duration-200 font-medium py-3 px-8 rounded-lg shadow-lg hover:shadow-xl text-lg"
          >
            Contact Us
          </button>
        </div>
      </div>

      {/* Modal Form */}
      <AlertDialog open={isOpen} onClose={closeModal}>
        <Card>
          <CardHeader>
            <CardTitle>Get in Touch</CardTitle>
            <p style={{ color: 'var(--black-shade-2)' }}>
              We'd love to hear from you. Send us a message!
            </p>
          </CardHeader>
          <CardContent>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { id: 'name', type: 'text', label: 'Name', placeholder: 'John Doe' },
                { id: 'email', type: 'email', label: 'Email', placeholder: 'john@example.com' },
                { id: 'subject', type: 'text', label: 'Subject', placeholder: 'Inquiry about your services' },
                { id: 'phone', type: 'tel', label: 'Phone', placeholder: '(123) 456-7890' }
              ].map((field) => (
                <div key={field.id} className="space-y-2">
                  <label
                    htmlFor={field.id}
                    className="block font-medium"
                    style={{ color: 'var(--text-color)' }}
                  >
                    {field.label}
                  </label>
                  <input
                    type={field.type}
                    id={field.id}
                    name={field.id}
                    className="w-full rounded-lg py-2.5 px-4 transition-colors duration-200"
                    style={{
                      backgroundColor: 'var(--white-shade-1)',
                      borderColor: 'var(--white-shade-2)',
                      color: 'var(--text-color)',
                      border: '2px solid'
                    }}
                    placeholder={field.placeholder}
                  />
                </div>
              ))}
              <div className="col-span-full space-y-2">
                <label
                  htmlFor="message"
                  className="block font-medium"
                  style={{ color: 'var(--text-color)' }}
                >
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={5}
                  className="w-full rounded-lg py-2.5 px-4 transition-colors duration-200"
                  style={{
                    backgroundColor: 'var(--white-shade-1)',
                    borderColor: 'var(--white-shade-2)',
                    color: 'var(--text-color)',
                    border: '2px solid'
                  }}
                  placeholder="How can we assist you?"
                ></textarea>
              </div>
            </form>
          </CardContent>
          <AlertDialogAction>
            <button
              type="button"
              onClick={closeModal}
              style={{ 
                backgroundColor: 'var(--white-shade-2)',
                color: 'var(--text-color)'
              }}
              className="font-medium py-2.5 px-5 rounded-lg transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              style={{ 
                backgroundColor: 'var(--base-shade-1)',
                color: 'var(--white-shade-1)'
              }}
              className="font-medium py-2.5 px-5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200"
            >
              Send Message
            </button>
          </AlertDialogAction>
        </Card>
      </AlertDialog>
    </div>
  );
};

export default ResponsiveContactForm;