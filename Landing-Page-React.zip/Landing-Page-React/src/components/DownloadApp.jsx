// components/DownloadApp.jsx
import React from 'react';

const DownloadApp = () => {
  return (
    <section className="download-app" id="download-app">
      <h2>Download Our App</h2>
      <p className="section-desc">
        Unlock all new amazing features with our mobile app. Manage your academic journey on the go, track activities, set goals,
        and enhance your productivity.
      </p>
      <div className="row">
        <div className="column">
          <img src="./images/download-app.png" alt="Download Our App" />
        </div>
        <div className="column">
          <div className="app-feature">
            <div>
              <i className="fas fa-bell"></i>
              <h3>Set Reminders</h3>
            </div>
            <p>
              Never miss a class or study session again. Set personalized reminders for all your academic activities and stay on
              top of your schedule.
            </p>
          </div>
          <div className="app-feature">
            <div>
              <i className="fas fa-download"></i>
              <h3>Access Anywhere</h3>
            </div>
            <p>
              Download your academic resources and access them offline. Stay productive and learn on the go, whether you're online
              or offline.
            </p>
          </div>
          <div className="app-feature">
            <div>
              <i className="fas fa-chart-pie"></i>
              <h3>Real-Time Analytics</h3>
            </div>
            <p>
              Track your progress with real-time analytics. Get insights into your study habits, monitor your goals, and make
              data-driven decisions to optimize your learning.
            </p>
          </div>
          <div className="download-btns">
            <a href="#google-play">
              <img src="./images/google-play.png" alt="Download on Google Play" />
            </a>
            <a href="#app-store">
              <img src="./images/app-store.png" alt="Download on the App Store" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DownloadApp;