import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import './styles/navbar.css';
import './styles/global.css';
import './styles/variables.css';
import './styles/main.css';
import './styles/downloadApp.css';
import './styles/footer.css';
import Navbar from './components/Navbar';
import Main from './components/Main';
import DownloadApp from './components/DownloadApp';
import ResponsiveContactForm from './components/ResponsiveContactForm';
import Footer from './components/Footer';
import './styles/contactForm.css';


const App = () => {
  return (
    <Router>
      <div>
        <Navbar />
        <Main />
        <DownloadApp />
        <div className="tailwind-scoped">
  <ResponsiveContactForm />
</div>
        
        <Footer />
      </div>
    </Router>
  );
};

export default App;