/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/components/ResponsiveContactForm.jsx",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontSize: {
        'sm': '14px',
        'base': '16px',
        'lg': '48px',
        'xl': '20px',
        '2xl': '24px', // Customize as needed
      },
      colors: {
        primary: '#123456', // Your custom colors here
      },
    },
  },
  plugins: [],
}